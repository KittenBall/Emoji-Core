local addonName, addon = ...

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "enUS")
if not L then return end

L["auto_complete_keyboard_press_tips"] = "Press space or number"
L["keyboard_emoji_pack_recent"] = "Recent"
L["keyboard_emoji_pack_recent_sub_group_recent"] = "Recent"
L["keyboard_emoji_pack_emoji"] = "Emoji"
L["keyboard_group_format"] = "%s (%d)"
L["keyboard_group_subgroup_count_title"] = "Subgroup count:"
L["keyboard_group_emoji_count_title"] = "Emoji count:"
L["keyboard_emoji_shortcode_title"] = "Shortcode:"
L["keyboard_emoji_variants_number_title"] = "Variants count:"
L["keyboard_emoji_keyword_title"] = "Keyword:"

L["settings_category_name"] = "Emoji"

L["settings_keyboard_section_title"] = "Emoji Keyboard"
L["settings_keyboard_default_width_title"] = "Default Width"
L["settings_keyboard_default_width_tooltip"] = "Adjust the default width of the emoji keyboard. You can still resize it using the keyboard's zoom feature."
L["settings_keyboard_default_height_title"] = "Default Height"
L["settings_keyboard_default_height_tooltip"] = "Adjust the default height of the emoji keyboard. You can still resize it using the keyboard's zoom feature."
L["settings_keyboard_pack_icon_size_title"] = "Pack Icon Size"
L["settings_keyboard_pack_icon_size_tooltip"] = "Set the icon size for emoji packs in the keyboard.\nNote: This refers to the pack icons, not individual emoji icons."
L["settings_keyboard_emoji_icon_size_title"] = "Emoji Icon Size"
L["settings_keyboard_emoji_icon_size_tooltip"] = "Set the icon size for individual emojis in the keyboard."
L["settings_keyboard_group_icon_size_title"] = "Group Icon Size"
L["settings_keyboard_group_icon_size_tooltip"] = "Set the icon size for emoji group icons in the keyboard."